"""Offline, candidate-only incremental review report; never approve, build or export data."""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import date, datetime
from pathlib import Path
import os
import re
import sys
import tempfile

from common import (
    DataError, ROOT, check_urls, https_url, json_bytes, load_catalog, read_json, require,
    sha256, unique_index, validate_schema, validate_snapshot,
)


REFRESH_VERSIONS = {
    "aa-intelligence-index": {"5.0"}, "vals-index": {"2.2"},
    "terminal-bench": {"4.0", "4.0.0"}, "deepswe": {"1.1"},
    "swe-bench-pro": {"2", "2.0", "V2 public"}, "osworld": {"2.1"},
    "automationbench": {"1.0.6"}, "hle": {"original-2025-04-03", "2025-04-03", "original-2025-05"},
    "gdpval-aa": {"2.1"}, "chartography": {None},
    "terminal-bench-science": {"0.1", "0.1.0"},
}


def refresh_policy(batch_id: str, scope: dict, targets: list[dict], benchmarks: dict) -> None:
    """Freeze the user-approved policy for this batch, not for unrelated future reviews."""
    if batch_id != "benchmark-refresh-2026-10-28":
        return
    require((scope["startDate"], scope["cutoff"]) == ("2026-04-28", "2026-10-28"),
            "refresh requires the approved fixed half-year window")
    require(scope["sourceUrl"] == "https://models.dev/models.json?type=all", "unexpected model scope source")
    require({target["id"] for target in targets} == set(REFRESH_VERSIONS),
            "refresh requires all eleven approved targets")
    for target in targets:
        for benchmark_id in target["benchmarkIds"]:
            benchmark = benchmarks[benchmark_id]
            if target["id"] == "swe-bench-pro":
                require(benchmark_id == "swe-bench-pro-v2", "SWE-bench Pro refresh allows only the explicit V2 public benchmark ID")
            value = benchmark["version"]
            normalized = value[1:] if isinstance(value, str) and value.startswith("v") else value
            allowed = normalized in REFRESH_VERSIONS[target["id"]]
            if target["id"] == "chartography" and isinstance(value, str):
                allowed = re.fullmatch(r"(?:commit[: ]+)?[0-9a-f]{40}", value) is not None
            require(allowed, f"{benchmark_id}: version outside approved refresh policy: {value}")
            require(not any(word in benchmark_id.lower() for word in ("diamond", "rolling", "hard-51", "automationbench-aa")),
                    f"{benchmark_id}: excluded benchmark variant")


def attachment(directory: Path, relative: str) -> Path:
    path = directory / relative
    require(not Path(relative).is_absolute() and ".." not in Path(relative).parts,
            f"review attachment escapes batch: {relative}")
    require(not path.is_symlink() and path.resolve().is_relative_to(directory.resolve()),
            f"review attachment must be inside batch: {relative}")
    return path


def digest(value) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def model_scope(scope: dict, batch_id: str) -> dict:
    require(type(scope.get("schemaVersion")) is int and scope["schemaVersion"] == 1,
            "invalid model scope schemaVersion")
    require(scope.get("batchId") == batch_id, "model scope belongs to another batch")
    require(digest(scope.get("responseSha256")), "model scope needs original response SHA-256")
    start, end = date.fromisoformat(scope["startDate"]), date.fromisoformat(scope["cutoff"])
    require(start <= end, "inverted model date window")
    require(bool(scope.get("sourceUrl")) and bool(scope.get("selectionPolicy")), "missing scope provenance")
    datetime.fromisoformat(scope["retrievedAt"].replace("Z", "+00:00"))
    models = unique_index(scope["models"], "scope model")
    require(bool(models), "empty model scope")
    for model in models.values():
        require(bool(model.get("name")), "scope model needs a name")
        value = model["releaseDate"]
        if re.fullmatch(r"\d{4}-\d{2}", value):
            from calendar import monthrange
            year, month = map(int, value.split("-"))
            low, high = date(year, month, 1), date(year, month, monthrange(year, month)[1])
        else:
            low = high = date.fromisoformat(value)
        require(start <= low <= high <= end, f"{model['id']}: release date outside fixed window")
    require(isinstance(scope.get("dateIssues"), list), "scope must record date issues")
    check_urls(scope)
    return models


def baseline_check(root: Path, baseline: dict, catalog, batch_id: str,
                   check_external: bool, android_root: Path | None = None) -> list[dict]:
    require(type(baseline.get("schemaVersion")) is int and baseline["schemaVersion"] == 1,
            "invalid baseline schemaVersion")
    require(baseline.get("batchId") == batch_id, "baseline belongs to another batch")
    current = unique_index(catalog.results, "result")
    for item in baseline["maintenanceResults"]:
        require(current.get(item["id"]) == item, f"protected maintenance result changed: {item['id']}")
    for key in ("benchmarks", "sources", "mappings"):
        for item in baseline["maintenanceEntities"][key]:
            require(getattr(catalog, key).get(item["id"]) == item,
                    f"protected {key} entity changed: {item['id']}")
    unique_index(baseline["maintenanceResults"], "baseline result")
    android = baseline["androidSnapshot"]
    require(digest(android.get("sha256")), "Android baseline needs SHA-256")
    validate_snapshot({"schemaVersion": 1, "version": android["version"], "scores": android["scores"]}, root)
    checks = []
    seen = set()
    for item in baseline["protectedFiles"]:
        relative = item["path"]
        require(relative not in seen, f"duplicate protected file: {relative}")
        seen.add(relative)
        require(digest(item.get("sha256")), f"invalid protected digest: {relative}")
        if relative == android["path"]:
            require(item["sha256"] == android["sha256"], "Android baseline hashes differ")
        external = relative.startswith("../model-atlas-android/")
        relative_path = Path(relative)
        allowed_parts = relative_path.parts[2:] if external else relative_path.parts
        require(not relative_path.is_absolute() and ".." not in allowed_parts,
                f"invalid protected path: {relative}")
        allowed_root = (android_root or root.parent / "model-atlas-android") if external else root
        path = allowed_root.joinpath(*relative_path.parts[2:]) if external else root / relative
        require(not path.is_symlink() and path.resolve().is_relative_to(allowed_root.resolve()),
                f"protected path escapes allowed repository: {relative}")
        if external and not check_external:
            checks.append({"path": relative, "status": "not-checked", "reason": "use --check-android with sibling checkout"})
            continue
        require(path.is_file(), f"protected file missing: {relative}")
        require(sha256(path.read_bytes()) == item["sha256"], f"protected file changed: {relative}")
        if relative == android["path"]:
            live = read_json(path)
            require(live["version"] == android["version"] and live["scores"] == android["scores"],
                    "Android baseline does not match protected snapshot")
        checks.append({"path": relative, "status": "verified"})
    require(android["path"] in seen, "Android snapshot must be a protected file")
    return checks


def baseline_status_index(baseline: dict) -> dict:
    result = {("result", item["id"]): item["status"] for item in baseline["maintenanceResults"]}
    entity_types = {"benchmarks": "benchmark", "sources": "source", "mappings": "mapping"}
    for document_key, entity_type in entity_types.items():
        result.update({(entity_type, item["id"]): item["status"]
                       for item in baseline["maintenanceEntities"][document_key]})
    return result


def validate_review_decisions(directory: Path, batch_id: str, entity_statuses: dict,
                              protected_statuses: dict, evidence_ids: set[str]) -> dict:
    """Require evidence-backed decision events for non-pending batch entities."""
    path = directory / "decisions.json"
    if path.exists() or path.is_symlink():
        document = read_json(attachment(directory, "decisions.json"))
    else:
        document = {"schemaVersion": 1, "batchId": batch_id, "decisions": []}
    validate_schema(document, "review-decisions.schema.json")
    require(document["batchId"] == batch_id, "review decisions belong to another batch")

    histories = {}
    for decision in document["decisions"]:
        key = (decision["entityType"], decision["entityId"])
        require(key in entity_statuses,
                f"review decision references an entity outside this batch: {key[0]} {key[1]}")
        require(key not in protected_statuses,
                f"review decision cannot alter a protected baseline entity: {key[0]} {key[1]}")
        for reference in decision["evidenceRefs"]:
            if reference not in evidence_ids:
                https_url(reference)
        history = histories.setdefault(key, [])
        if history:
            previous = history[-1]
            require(decision["reviewedAt"] >= previous["reviewedAt"],
                    f"review decision dates are out of order for {key[0]} {key[1]}")
            require(decision["status"] != previous["status"],
                    f"duplicate review decision status for {key[0]} {key[1]}")
        history.append(decision)

    latest = {key: rows[-1] for key, rows in histories.items()}
    for key, status in entity_statuses.items():
        protected_status = protected_statuses.get(key)
        if protected_status is not None:
            require(status == protected_status, f"protected baseline status changed: {key[0]} {key[1]}")
            continue
        decision = latest.get(key)
        if status == "pending":
            require(decision is None,
                    f"pending entity has a completed review decision: {key[0]} {key[1]}")
        else:
            require(decision is not None,
                    f"{status} entity lacks an auditable review decision: {key[0]} {key[1]}")
            require(decision["status"] == status,
                    f"review decision status does not match maintenance data: {key[0]} {key[1]}")


def review_candidates(root: Path, batch_path: Path, check_android: bool = False,
                      android_root: Path | None = None) -> dict:
    try:
        return _review_candidates(root, batch_path, check_android, android_root)
    except DataError:
        raise
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        raise DataError(f"invalid review attachment: {error}") from error


def _review_candidates(root: Path, batch_path: Path, check_android: bool = False,
                       android_root: Path | None = None) -> dict:
    root, batch_path = root.resolve(), batch_path.resolve()
    require(batch_path.is_relative_to(root / "data" / "reviews"), "batch must be under data/reviews/")
    batch = read_json(batch_path)
    validate_schema(batch, "candidate-review.schema.json", root)
    directory = batch_path.parent
    scope = read_json(attachment(directory, batch["scopeFile"]))
    models = model_scope(scope, batch["id"])
    baseline = read_json(attachment(directory, batch["baselineFile"]))
    catalog = load_catalog(root)
    checks = baseline_check(root, baseline, catalog, batch["id"], check_android, android_root)
    targets, evidence, systems = [], [], []
    for relative in batch["evidenceFiles"]:
        document = read_json(attachment(directory, relative))
        validate_schema(document, "candidate-evidence.schema.json", root)
        check_urls(document)
        targets.extend(document["targets"])
        evidence.extend(document["evidence"])
        systems.extend(document["systemOnly"])
    target_index = unique_index(targets, "review target")
    require(set(target_index) == set(batch["targetIds"]), "target coverage does not match batch")
    unique_index(evidence, "evidence")
    unique_index(systems, "system-only record")
    benchmark_targets = {}
    evidence_sources = set()
    for entry in evidence:
        require(entry["sourceId"] in catalog.sources, f"unknown evidence source: {entry['sourceId']}")
        require(bool(entry.get("url")) and bool(entry.get("locator")) and bool(entry.get("excerpt")),
                f"{entry['id']}: incomplete evidence")
        require(entry.get("responseSha256") is None or digest(entry["responseSha256"]),
                f"{entry['id']}: invalid response digest")
        datetime.fromisoformat(entry["retrievedAt"].replace("Z", "+00:00"))
        evidence_sources.add(entry["sourceId"])
    for target in targets:
        require(target["status"] in ("collected", "blocked"), "invalid investigation status")
        require(bool(target["notes"]) and bool(target["officialUrls"]) and bool(target["searches"]),
                f"{target['id']}: missing investigation coverage")
        for url in target["officialUrls"]:
            https_url(url)
        for search in target["searches"]:
            require(type(search["tier"]) is int and search["tier"] in (1, 2, 3, 4), "invalid source priority")
            require(bool(search["url"]) and bool(search["outcome"]), "missing search outcome")
        for benchmark_id in target["benchmarkIds"]:
            require(benchmark_id in catalog.benchmarks, f"unknown target benchmark: {benchmark_id}")
            require(benchmark_id not in benchmark_targets, f"benchmark assigned to multiple targets: {benchmark_id}")
            benchmark_targets[benchmark_id] = target["id"]
    refresh_policy(batch["id"], scope, targets, catalog.benchmarks)
    all_results = unique_index(catalog.results, "result")
    old_ids = {row["id"] for row in baseline["maintenanceResults"]}
    candidate_ids = set(batch["candidateResultIds"])
    require(not old_ids & candidate_ids, "old baseline results cannot be new candidates")
    # Explicit membership avoids silently including the three pending legacy rows.
    require(candidate_ids <= set(all_results), "batch references an unknown candidate result")
    android_ids = {row["id"] for row in baseline["androidSnapshot"]["scores"]}
    android_source_ids = {
        row["sourceId"] for row in baseline["maintenanceResults"]
        if row["id"] in android_ids and row["status"] == "approved"
    }
    candidates = []
    counts = Counter()
    represented_models = set()
    entity_statuses = {}
    protected_statuses = baseline_status_index(baseline)
    for result_id in sorted(candidate_ids):
        result = all_results[result_id]
        if batch["id"] == "benchmark-refresh-2026-10-28":
            conditions = [result.get("harness") or "", result.get("reasoningEffort") or "", *result["unrepresentedConditions"]]
            require(not any(
                re.search(r"\bdefault[- ]fallbacks?\b", text, re.IGNORECASE)
                or re.fullmatch(r"\s*opus[- ](?:4\.8|5)\s+fallbacks?\s*", text, re.IGNORECASE)
                for text in conditions
            ), f"{result_id}: fallback system must not be attributed to a single model")
        require(result["benchmarkId"] in benchmark_targets, f"{result_id}: outside target benchmark list")
        benchmark = catalog.benchmarks[result["benchmarkId"]]
        source = catalog.sources[result["sourceId"]]
        mapping = catalog.mappings[result["mappingId"]]
        dependencies = (("benchmark", benchmark), ("source", source), ("mapping", mapping))
        for entity_type, entity in dependencies:
            entity_statuses[(entity_type, entity["id"])] = entity["status"]
        entity_statuses[("result", result_id)] = result["status"]
        if any(entity["status"] == "rejected" for _, entity in dependencies):
            require(result["status"] == "rejected",
                    f"{result_id}: result depending on a rejected entity must also be rejected")
        require(source["id"] in evidence_sources, f"{result_id}: source evidence missing")
        model_id = mapping["modelId"]
        require(model_id is None or model_id in models, f"{result_id}: model outside frozen scope")
        blockers = []
        if result["status"] == "pending":
            blockers.append("maintenance-review-pending")
        elif result["status"] == "rejected":
            blockers.append("result-rejected")
        if not model_id or not mapping["evidenceUrl"] or not mapping["catalogUrl"]:
            blockers.append("model-identity-unconfirmed")
        license_info = source["license"]
        if license_info["redistribution"] != "allowed" or not all(license_info[key] for key in ("name", "url", "licenseFile")):
            blockers.append("redistribution-and-client-attribution-unconfirmed")
        if source["id"] not in android_source_ids:
            blockers.append("source-attribution-not-in-current-android-bundle")
        if result["unrepresentedConditions"]:
            blockers.append("essential-conditions-not-representable-in-android-v1")
        target_id = benchmark_targets[benchmark["id"]]
        if batch["id"] == "benchmark-refresh-2026-10-28" and target_id == "swe-bench-pro":
            require(not any(word in (result["subset"] or "").lower() for word in ("private", "commercial", "hard")),
                    f"{result_id}: SWE-bench Pro subset outside V2 public")
        if model_id:
            represented_models.add(model_id)
            counts[model_id, target_id] += 1
        candidates.append({
            "result": result, "status": result["status"], "modelId": model_id,
            "sourceModelName": mapping["sourceModelName"],
            "targetId": target_id, "benchmark": benchmark, "source": source,
            "mapping": mapping, "blockers": blockers,
        })
    coverage = []
    for target_id in batch["targetIds"]:
        target = target_index[target_id]
        rows = [row for row in candidates if row["targetId"] == target_id]
        require((target["status"] == "collected") == bool(rows), f"{target_id}: investigation status contradicts candidate count")
        coverage.append({**target, "candidateCount": len(rows),
                         "matchedModelCount": len({row["modelId"] for row in rows if row["modelId"]})})
    validate_review_decisions(directory, batch["id"], entity_statuses, protected_statuses,
                              {entry["id"] for entry in evidence})
    candidate_ids_by_status = {
        status: sorted(row["result"]["id"] for row in candidates if row["status"] == status)
        for status in ("approved", "pending", "rejected")
    }
    client_compatible_approved = sorted(
        row["result"]["id"] for row in candidates
        if row["status"] == "approved" and "source-attribution-not-in-current-android-bundle" not in row["blockers"]
    )
    return {
        "mode": "candidate-only", "deployable": False, "actualChangesApplied": False,
        "batchId": batch["id"], "notes": batch["notes"],
        "scope": {key: scope[key] for key in ("sourceUrl", "responseSha256", "retrievedAt", "startDate", "cutoff", "dateIssues")},
        "summary": {"scopeModels": len(models), "investigatedTargets": len(coverage),
                    "candidateResults": len(candidates), "modelsWithCandidates": len(represented_models),
                    "unmappedCandidates": sum(row["modelId"] is None for row in candidates),
                    "systemOnlyRecords": len(systems),
                    "systemOnlyRows": sum(len(item.get("rows", [item])) for item in systems),
                    "approvedNewResults": len(candidate_ids_by_status["approved"]),
                    "pendingResults": len(candidate_ids_by_status["pending"]),
                    "rejectedResults": len(candidate_ids_by_status["rejected"])},
        "maintenanceDiff": {"hypothetical": True, "beforeCount": len(old_ids),
                            "retainedBaseline": sorted(old_ids), "wouldRemove": [],
                            "wouldAddApproved": candidate_ids_by_status["approved"],
                            "wouldAddPending": candidate_ids_by_status["pending"],
                            "wouldAddRejected": candidate_ids_by_status["rejected"]},
        "androidDiff": {"hypothetical": True, "baselineKind": "bundled-assets-not-live-server",
                        "baselineVersion": baseline["androidSnapshot"]["version"],
                        "baselineSha256": baseline["androidSnapshot"]["sha256"],
                        "beforeCount": len(android_ids), "retainedBaseline": sorted(android_ids), "wouldRemove": [],
                        "wouldConsiderAdding": client_compatible_approved,
                        "approvedButAttributionBlocked": sorted(set(candidate_ids_by_status["approved"]) - set(client_compatible_approved)),
                        "warning": "Not a wire snapshot. Keep bundled scores; remote v1 sync does not update attributions, so new sources need a compatible Android attribution bundle."},
        "coverage": coverage,
        "modelCoverage": [{**model, "targets": {
            target_id: {"candidateCount": counts[model_id, target_id],
                        "status": "candidate-found" if counts[model_id, target_id] else "not-collected",
                        "note": None if counts[model_id, target_id] else "本轮列明来源未收录；不是穷尽全网后认定无成绩。"}
            for target_id in batch["targetIds"]}} for model_id, model in sorted(models.items())],
        "candidates": candidates, "evidence": evidence, "systemOnly": systems,
        "protectedFiles": checks,
    }


def markdown(report: dict) -> str:
    def cell(value):
        return str(value if value is not None else "未知").replace("|", "\\|").replace("\n", " ")

    summary = report["summary"]
    lines = ["# Benchmark 候选审核预览", "", "**candidate-only：不是发布包；未修改 Android 或部署。**", "",
             f"批次：`{report['batchId']}`；模型发布日期窗口：{report['scope']['startDate']}～{report['scope']['cutoff']}（含两端）。",
             f"范围 {summary['scopeModels']} 个模型 ID、{summary['investigatedTargets']} 项；候选 {summary['candidateResults']} 条（approved {summary['approvedNewResults']} / pending {summary['pendingResults']} / rejected {summary['rejectedResults']}），明确关联 {summary['modelsWithCandidates']} 个模型。", "",
             "所有原始指标保持原单位；不同版本／Agent／工具／预算不合并，不取最高分，不生成综合排名。",
             "没有候选仅表示本轮已列明来源未收录，不表示已逐模型穷尽全网。", "",
             "## 增量影响（假设）", "",
             "保留现有维护基线和 Android 随包成绩；本报告不是线上站点验收，也不执行替换。", "",
             "### 维护层候选状态", "",
             f"- 保留基线 {len(report['maintenanceDiff']['retainedBaseline'])} 条；拟移除 {len(report['maintenanceDiff']['wouldRemove'])} 条。",
             f"- 新批准 {len(report['maintenanceDiff']['wouldAddApproved'])} 条；继续待审 {len(report['maintenanceDiff']['wouldAddPending'])} 条；拒绝 {len(report['maintenanceDiff']['wouldAddRejected'])} 条。", "",
             "### Android 随包基线", "",
             f"- 保留 v{report['androidDiff']['baselineVersion']} 的 {len(report['androidDiff']['retainedBaseline'])} 条成绩；拟移除 {len(report['androidDiff']['wouldRemove'])} 条。",
             f"- 当前归属包兼容、可进一步考虑的新增成绩：{len(report['androidDiff']['wouldConsiderAdding'])} 条；已批准但归属包不兼容：{len(report['androidDiff']['approvedButAttributionBlocked'])} 条。", ""]
    if report.get("stagingOnly"):
        lines.insert(3, "**隔离暂存预览：候选尚未完整写入日常维护文件；本报告不表示维护层已完成导入。**")
    lines.extend(["Android 候选集合见下表及 JSON 的 `candidates`。公开可读不等于获准分发；v1 远程更新不传归属信息。", "",
                   "## 项目调查覆盖", "", "| 项目 | 候选成绩 | 已关联模型 | 调查结论 |", "| --- | ---: | ---: | --- |"])
    for target in report["coverage"]:
        lines.append(f"| {cell(target['id'])} | {target['candidateCount']} | {target['matchedModelCount']} | {cell(target['notes'])} |")
    lines.extend(["", "## 原始候选成绩（分批审核状态）", "",
                  "| 状态 | 结果 ID | 规范模型 ID | 评测及版本 | 原值／指标／单位 | 配置 | 出处定位 | 阻塞／说明 |",
                  "| --- | --- | --- | --- | --- | --- | --- | --- |"])
    for row in report["candidates"]:
        result, benchmark = row["result"], row["benchmark"]
        fields = [row["status"], result["id"], row["modelId"], f"{benchmark['name']} / {benchmark['version']}",
                  f"{result['score']} / {benchmark['metric']} / {benchmark['unit']}",
                  f"subset={result['subset']}; harness={result['harness']}; reasoning={result['reasoningEffort']}; tools={result['toolsEnabled']}",
                  f"{row['source']['url']} — {result['sourceLocator']}", "; ".join(row["blockers"])]
        lines.append("| " + " | ".join(cell(field) for field in fields) + " |")
    lines.extend(["", "## 模型覆盖矩阵", "", "零表示本轮未收录，不是模型分数为零。", "",
                  "| 模型 ID | " + " | ".join(target["id"] for target in report["coverage"]) + " |",
                  "| --- | " + " | ".join("---:" for _ in report["coverage"]) + " |"])
    for model in report["modelCoverage"]:
        lines.append("| " + cell(model["id"]) + " | " + " | ".join(str(value["candidateCount"]) for value in model["targets"].values()) + " |")
    lines.extend(["", "## 检索记录与缺口", ""])
    for target in report["coverage"]:
        lines.extend([f"### {target['id']}", ""])
        for search in target["searches"]:
            lines.append(f"- 来源优先级 {search['tier']}：{search['url']} — {search['outcome']}")
        lines.append("")
    lines.extend(["## 系统级记录与未核实线索", "", "多模型 fallback 不作为单个模型的候选成绩；此处也可包括身份、版本或原始精度尚未核实的调查线索，不能据此认定均为组合系统。完整依据和排除原因见 JSON 的 `systemOnly`。", "",
                  f"本轮记录 {summary['systemOnlyRecords']} 组／{summary['systemOnlyRows']} 行记录。", "", "## 保护校验", ""])
    lines.extend(f"- `{entry['path']}`：{entry['status']}" for entry in report["protectedFiles"])
    lines.extend(["", "批准／拒绝必须在同目录 `decisions.json` 追加审核人、日期、理由和证据引用，并与维护数据状态一致。审批不会自动批准依赖；未核实的分发条件仍阻止发布。", ""])
    return "\n".join(lines)


def write_report(root: Path, output: Path, report: dict) -> dict:
    root = root.resolve()
    output = output.absolute()
    require(not output.is_symlink() and output.resolve().is_relative_to(root / "build"),
            "candidate reports must be under repository build/")
    require(output.resolve() != root / "build", "use a dedicated candidate report directory")
    content_by_name = {"report.json": json_bytes(report), "report.md": markdown(report).encode("utf-8")}
    if output.exists():
        require(output.is_dir(), "candidate output is not a directory")
        names = {path.name for path in output.iterdir()}
        require(names <= {"report.json", "report.md"}, "candidate output contains other artifacts; use a dedicated empty directory")
        if names:
            require("report.json" in names, "existing report directory has no candidate identity")
            previous = read_json(output / "report.json")
            require(previous.get("mode") == "candidate-only" and previous.get("deployable") is False
                    and previous.get("batchId") == report["batchId"],
                    "output belongs to another report mode or candidate batch")
            for name in names:
                require((output / name).read_bytes() == content_by_name[name],
                        f"existing candidate report differs; use a fresh directory: {output / name}")
    # Never write manifest.json, scores-v*.json, release config or source data.
    for name in ("report.json", "report.md"):
        path = output / name
        require(not path.is_symlink() and path.resolve().is_relative_to((root / "build").resolve()),
                f"report output escapes build/: {path}")
    output.mkdir(parents=True, exist_ok=True)
    for name, content in content_by_name.items():
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=output, prefix=".candidate-", delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(content)
            # Replace the directory entry, never truncate a potentially hard-linked inode.
            os.replace(temporary, output / name)
        finally:
            if temporary is not None and temporary.exists():
                temporary.unlink()
    return report


def write_preview(root: Path, batch_path: Path, output: Path, check_android: bool = False) -> dict:
    return write_report(root, output, review_candidates(root, batch_path, check_android))


def staging_preview(root: Path, check_android: bool = False) -> dict:
    """Validate a temporary hypothetical merge without modifying source files."""
    from merge_candidate_staging import REVIEW, plan

    root = root.resolve()
    with tempfile.TemporaryDirectory(prefix="candidate-review-") as directory:
        sandbox = Path(directory).resolve()
        require(not sandbox.is_relative_to(root), "temporary directory must be outside repository")
        plan(root, sandbox)
        report = review_candidates(sandbox, sandbox / REVIEW / "batch.json", check_android,
                                   android_root=root.parent / "model-atlas-android")
    report["stagingOnly"] = True
    report["notes"] += " Hypothetical staging preview; candidates are not yet fully imported into maintenance documents."
    return report


def print_protection_notice(report: dict) -> None:
    if any(entry["status"] == "not-checked" for entry in report["protectedFiles"]):
        print("NOTICE: Android protected files not checked; use --check-android with the sibling checkout")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=Path, default=ROOT / "data/reviews/2026-10-28/batch.json")
    parser.add_argument("--output", type=Path, default=ROOT / "build/candidate-review-2026-10-28-android-additive")
    parser.add_argument("--check-android", action="store_true", help="also verify protected files in sibling Android checkout")
    parser.add_argument("--check", action="store_true", help="validate review only, without writing reports")
    parser.add_argument("--staging", action="store_true", help="preview hypothetical staging merge in a temporary directory without importing")
    args = parser.parse_args()
    try:
        if args.staging:
            report = staging_preview(ROOT, args.check_android)
            if not args.check:
                write_report(ROOT, args.output, report)
        else:
            report = review_candidates(ROOT, args.batch, args.check_android) if args.check else write_preview(ROOT, args.batch, args.output, args.check_android)
        summary = report["summary"]
        print(f"OK: candidate-only, {summary['candidateResults']} candidates "
              f"({summary['approvedNewResults']} approved, {summary['pendingResults']} pending, "
              f"{summary['rejectedResults']} rejected); no export/deployment")
        print_protection_notice(report)
        if not args.check:
            print(f"Reports: {args.output / 'report.md'} and report.json")
        return 0
    except (DataError, OSError, KeyError, TypeError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
